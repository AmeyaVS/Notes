
/* Function Prototype */
int printf();

int main()
{
	printf("Hello World\n");
	return(0); /* to keep the OS Happy */
}
