int a,b;
int c,d ;

int main()
{
	a=40;
	b=20;
	c = a + b;
	d = b + c;
}
