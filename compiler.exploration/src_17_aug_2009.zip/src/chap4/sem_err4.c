
int main()
{
	float b,c;

	b = 30.45;
	c = 40.36;

	b = c ;

	break; /* using break statement in a non-loop context */

	return(0);
}
