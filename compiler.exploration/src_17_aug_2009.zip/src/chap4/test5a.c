/* Global Structure */
struct my_info 
{
	int v1,v2;
	char c1;
	struct my_info *next;
} var1;


/* Function */
int main()
{

	int h;

   h=20;	
}

