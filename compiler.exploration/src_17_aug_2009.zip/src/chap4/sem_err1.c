
int main()
{
	int a,b;

	a=1;
	b=2;
	c=3; /* Use of undeclared variable */

	a = b + c;

	return(a);

}
