
int main()
{
	char *a;

	float b,c;

	b = 30.45;
	c = 40.36;

	a = b + c; /* Assigning a float to char pointer */

	return(0);

}
