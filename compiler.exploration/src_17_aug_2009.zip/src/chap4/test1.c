int a,b,c;
float d,e,f;
char i,j,k;
