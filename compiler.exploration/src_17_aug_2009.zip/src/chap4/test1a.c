int a,b c; /* Missing comma */
