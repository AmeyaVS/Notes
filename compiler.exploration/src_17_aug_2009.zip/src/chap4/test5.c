int var1;
int var2[10];
int var3[10][20];

int *var4;
int *var5[50];



/* Function */
int main()
{
   var1=20;	
}

/* Another function */
int ab(int one,char two, float three,int four)
{
	/* Local Variables */
	int h,j;
	char k[56][67];

	h=10;
}

