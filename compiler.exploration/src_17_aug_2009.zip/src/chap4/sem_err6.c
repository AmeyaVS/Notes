
int main()
{
	int a;

	int b,c;
	float a; /* declaring a variable twice in the same scope */

	b = 30;
	c = 40;

	a = b + c;

	return(a);

}
