
int main()
{

	float b,c;

	b = 30.45;
	c = 40.36;

	b = c -> f1; /* using '->' operator on a float Variable */

	return(0);
}
