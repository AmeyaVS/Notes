#ifndef STL_H
#define STL_H

#include <algorithm>
#include <numeric>
#include <functional>
#include <iterator>
#include <list>
#include <deque>
#include <map>
//#include <pair>
#include <set>
#include <stack>
#include <vector>
#include <string>
#include <iostream>
#include <ext/hash_map>
#include <ext/hash_set>
using  namespace std;
using namespace __gnu_cxx;

#endif

