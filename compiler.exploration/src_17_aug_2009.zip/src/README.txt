Each of the directories contains the sources used for the respective chapters.
the html directory contains the HTML based documentation for the Sources.

These sources have been tested on cygwin version 1.5 with the following versions of the supporting utilities.

flex version 2.5.4
bison (GNU Bison) 2.3
gcc version 3.4.4

There is no reason, why it would not work in the versions later than these.
It should be compilable on LINUX too.

In case you see any issues in compilation, please post the question in
the yahoo groups at http://in.groups.yahoo.com/group/compilers2009
or 
email me at raghavan.compilers2009@yahoo.co.in


V.Raghavan
