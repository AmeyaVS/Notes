/* Function */
int main()
{
	/* Local Variables */
	int h;
	int arr[30][40][50];

	/* Initialization */
	h=30;

	/* Array accesses */
	arr[6][23][9]=h;
}
