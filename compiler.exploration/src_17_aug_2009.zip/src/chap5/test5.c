int x,z;

int
func (int a, int b)
{
  if (a < b) {
      z = 30;
  } else {
      z = 40;
  }
  x=90;

}
