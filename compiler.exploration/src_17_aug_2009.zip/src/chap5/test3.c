int *p;
int x;

/* Function */
int main()
{
	/* Move 10 into x */
	p=&x;
	*p=10;
}
