
/* Function */
int main()
{
	/* Local Variables */
	int var;
	int arr[50];

	/* Array accesses */
	arr[43]=7;
	var = arr[43];
}
