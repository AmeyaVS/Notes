/* Function */
int main()
{
	/* Local Variables */
	int v1,v2,v3,v4;

	v2=200;
	v3=300;
	v4=400;

	/* Simple assignment statements */
	v1 = v2 + v3 - v4 ;

}
