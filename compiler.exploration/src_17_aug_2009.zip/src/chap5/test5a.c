int x,z;

int
func (int a, int b,int c,int d)
{
  if ((a < b) || ( c < d )) {
      z = 30;
  } else {
      z = 40;
  }
  x=90;

}
