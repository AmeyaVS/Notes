/* Variables */
int x,arr[20][30];


/* Function */
int main()
{
	/* Array accesses */
	x = arr[5][9];
}
