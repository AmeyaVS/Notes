int *p;
int arr[10];

/* Function */
int main()
{
	/* Move 10 into arr[3] */
	p=&arr[3];
	*p=10;
}
