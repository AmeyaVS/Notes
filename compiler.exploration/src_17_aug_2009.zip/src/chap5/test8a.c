int z;

int add_func(int a,int b)
{
	int c;

	c = a + b;

	return(c); 
}

int main()
{
	int v1,v2,v3,v4;

	v1=10;
	v2=20;

	v3=add_func((v1+6),v2);

	z=v3+5;
}

