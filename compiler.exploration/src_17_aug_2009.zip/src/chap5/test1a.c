/* Function */
int main()
{
	/* Local Variables */
	int v1,v2,v3,v4;

	/* Simple assignment statements */
	v1=50;
	v2=30;

	v3 = v1 + v2 ;
	v4 = v1 + 34 - (45 *v3 - v2 ) ;

}
