int *p;
int x,y;

/* Function */
int main()
{
	x=10;

	/* Move value of x into y */
	p=&x;
	y=*p;
}
