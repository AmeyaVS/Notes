int
main ()
{
  int i = 0;

  while (i < 5) {
    puts ("Hi\n");
    i++;
  }

  for (i = 0; i < 10; i++) {
    puts ("Hello World\n");
  }
}
