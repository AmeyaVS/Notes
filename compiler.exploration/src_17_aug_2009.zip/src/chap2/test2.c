int
main ()
{
  int i;

  /* This is a comment.This will be stripped by Lexical Analyser */

  for (i = 0; i < 10; i++) {
    printf ("Hello World\n");
  }
}
