/* 
	Constant Folding 
	Access of array elements using constant valued indexes
*/

int area;
int length,breadth,perimeter;


int func1()
{

	length=5;
	breadth=7;

	area = length*breadth ; 

	perimeter=2*(length+breadth);

}
