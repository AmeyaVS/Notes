int c;
int func()
{
	int a,b,d,e,f;
	int g;

	f = b + c;
	c=b;

	return(f);
}
