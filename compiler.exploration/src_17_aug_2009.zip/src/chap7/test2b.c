/* 
	Copy Propagation
*/

int a,b,c,d,e,f,g;

void func()
{

	int i,x;

	b = a; 

	d = (b + c)*f;
	e = (a + c)*g ;
}
