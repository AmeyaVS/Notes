int a[100],b[100];

int transform(int n,int factor)
{
	int i;

	i=0;
	while( 1 == 1 )
	{
		b[i]=a[i]+(factor *2);
		i = i + 1;
		if( i >= n ){
			break;
		}
	}

}

