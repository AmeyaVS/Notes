/*
	All the Transformations at Work
	(1) Common Expression Elimination
	(2) Constant Propagation
	(3) Constant Folding
	(4) Dead Assignment Elimination
*/
int a[45];

int func()
{
	a[5]=25;
	a[6]=30;
}
	
