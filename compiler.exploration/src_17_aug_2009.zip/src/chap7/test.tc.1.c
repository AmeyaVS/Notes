/*
Simple example
*/

int a,b,c,d,e,f,g;

int func()
{
	a = b + c;
	f =  d + e ;
	g = a + f ;
	f = a - b ;
	d = f + g;
}
	
