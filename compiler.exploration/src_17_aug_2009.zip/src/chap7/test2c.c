/* 
	Constant Folding
*/

int a,b,c,d,e,f,g;

int func1()
{
	int i;

	b = 5;
	a = 6 ;

	d = f / ( b * a ) ;
	e = g /f ;

}

