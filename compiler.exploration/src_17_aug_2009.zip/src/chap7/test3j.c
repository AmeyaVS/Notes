int b,c,f;
void func()
{

	f = b + c;
	b = c;
}
