int arr[50];
int x,y,z;

int func(int i,int j)
{
	x = arr[i];
	arr[j]=y;
	z = arr[i];
}
	
