int x,y,d,e,b,j,k;
int func()
{
	y = d * e;
	x = b + y;
	b = y;
	y = j + k;
}
