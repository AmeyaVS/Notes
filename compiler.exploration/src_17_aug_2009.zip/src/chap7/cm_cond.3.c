int arr[100];

int f1();

int func(int a,int b)
{
	int change,ret;

	change=0;
	if( a > b ){
		change=1;
	}


	while( 1 == 1 ){

		ret=f1(change);

		change=0;

		if(ret == 0 ){
			break;
		}

	}
	return;
}

