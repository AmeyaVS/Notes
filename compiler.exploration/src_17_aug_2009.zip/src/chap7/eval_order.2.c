
	int y,d,e,x,b,j,k;

int func2()
{

	y = d * e;
	x = b + y;
	b = y;
	y = j + k;

	return(0);
}

