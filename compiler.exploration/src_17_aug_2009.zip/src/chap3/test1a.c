/* Function */
int func( int v1,int v2)
{
	int v3,v4;

	v3=v1+v2  /* syntax error - Missing Semicolon */
	v4=v1-v2;

	return(v3*v4);
}
