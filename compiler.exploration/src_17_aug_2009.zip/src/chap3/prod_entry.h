#ifndef	PROD_ENTRY_H
typedef struct
{
   int lhs_elem;
   int no_of_elem_in_rhs;
   int rule_no;
}
prod_entry;

#define	PROD_ENTRY_H
#endif
